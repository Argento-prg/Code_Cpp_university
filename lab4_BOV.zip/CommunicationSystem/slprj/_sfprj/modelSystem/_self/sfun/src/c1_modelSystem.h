#ifndef __c1_modelSystem_h__
#define __c1_modelSystem_h__

/* Include files */
#include "sf_runtime/sfc_sf.h"
#include "sf_runtime/sfc_mex.h"
#include "rtwtypes.h"
#include "multiword_types.h"

/* Type Definitions */
#ifndef typedef_SFc1_modelSystemInstanceStruct
#define typedef_SFc1_modelSystemInstanceStruct

typedef struct {
  SimStruct *S;
  ChartInfoStruct chartInfo;
  uint32_T chartNumber;
  uint32_T instanceNumber;
  int32_T c1_sfEvent;
  boolean_T c1_isStable;
  boolean_T c1_doneDoubleBufferReInit;
  uint8_T c1_is_active_c1_modelSystem;
} SFc1_modelSystemInstanceStruct;

#endif                                 /*typedef_SFc1_modelSystemInstanceStruct*/

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern const mxArray *sf_c1_modelSystem_get_eml_resolved_functions_info(void);

/* Function Definitions */
extern void sf_c1_modelSystem_get_check_sum(mxArray *plhs[]);
extern void c1_modelSystem_method_dispatcher(SimStruct *S, int_T method, void
  *data);

#endif
